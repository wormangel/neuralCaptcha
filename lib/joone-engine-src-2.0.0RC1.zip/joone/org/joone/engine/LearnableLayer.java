package org.joone.engine;


public interface LearnableLayer extends Learnable, NeuralLayer {
}