package org.joone.util;

/**
 * @deprecated Use {@link PlugInEvent}
 */
public class OutputPluginEvent extends PlugInEvent {
    
    public OutputPluginEvent(AbstractConverterPlugIn aPlugIn) {
        super(aPlugIn);
    }
}
