/* Joone */

package org.joone.util;

/**
 * @deprecated Use {@link PlugInListener}
 */
public interface OutputPluginListener extends PlugInListener {
}
