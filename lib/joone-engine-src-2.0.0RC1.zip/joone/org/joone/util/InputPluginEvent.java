package org.joone.util;

/**
 * @deprecated Use {@link PlugInEvent}
 */
public class InputPluginEvent extends PlugInEvent {
    
    public InputPluginEvent(AbstractConverterPlugIn aPlugIn) {
        super(aPlugIn);
    }
}
